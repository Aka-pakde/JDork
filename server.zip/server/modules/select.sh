#!/bin/bash
if [ ! -d $HOME/payload ]
then
	mkdir $HOME/payload
fi
if [ -e $HOME/payload/index.php ]
then
	rm $HOME/payload/index.php
fi

if [ "$(ls -A $HOME/payload)" ]
then
	echo ''
        echo "file list"
        echo "========="
        echo -e '\033[1;32m'
	ls $HOME/payload | cat -n
	echo -e '\033[1;39m'
	echo -n "want to add files in file list y/n: "
	read sel
	if [ $sel == "y" ]
	then
		echo ''
		echo -n "Enter file path [example : /sdcard/p.apk] : "
       		read file
		if [[ $file != "" ]]; then
			cp -r $file $HOME/payload
		else
			exit
		fi
		echo ''
        	echo "New file list"
        	echo "========="
        	echo -e '\033[1;32m'
		cd $HOME/payload
        	ls | cat -n
		echo -e '\033[1;39m'
        	echo -n "select your choice : "
        	read choice
        	if [[ $choice == "" ]]
        	then
                	exit
        	fi
        	out=`ls | sed -n $choice'p'`
        	touch index.php
        	echo "<?php" >> index.php
        	echo "header('location:$out');" >> index.php
        	echo "?>">> index.php
        	echo -n "Enter port: "
        	read port
		if [[ $port == "" ]]
		then
			exit
		fi
		echo ''
        	echo -e "Server started \033[1;36mhttp://localhost:$port\033[1;39m"
        	echo ''
        	echo "press ctrl + c for exit"
        	while [ 1 ]
        	do
                	if [ -d $HOME/payload ]
                	then
                		cd $HOME/payload && php -S localhost:$port > /dev/null 2>&1 &
                		sleep 1
                	fi
        	done
	else
		cd $HOME/payload
		echo -n "select your choice : "
                read choice
		if [[ $choice == "" ]]
                then
                        exit
                fi
                out=`ls | sed -n $choice'p'`
                touch index.php
                echo "<?php" >> index.php
                echo "header('location:$out');" >> index.php
                echo "?>">> index.php
                echo -n "Enter port: "
                read port
		if [[ $port == "" ]]
		then
			exit
		fi
                echo ''
        	echo -e "Server started \033[1;36mhttp://localhost:$port\033[1;39m"
        	echo ''
        	echo "press ctrl + c for exit"
        	while [ 1 ]
        	do
                	if [ -d $HOME/payload ]
                	then
                		cd $HOME/payload && php -S localhost:$port > /dev/null 2>&1 &
                		sleep 1
                	fi
        	done
	fi
else
	echo ''
	echo -n "Enter file path [example : /sdcard/p.apk] : "
	read file
	if [[ $file != "" ]]
	then
		cp -r $file $HOME/payload
	else
		exit
	fi
	echo ''
	echo "file list"
	echo "========="
	echo -e '\033[1;32m'
	cd $HOME/payload
	ls | cat -n
	echo -e "\033[1;39m"
	echo -n "select your choice : "
	read choice
	if [[ $choice == "" ]]
	then
        	exit
	fi
	out=`ls | sed -n $choice'p'`
	touch index.php
	echo "<?php" >> index.php
	echo "header('location:$out');" >> index.php
	echo "?>">> index.php
	echo -n "Enter port: "
	read port
	if [[ $port == "" ]]
	then
		exit
	fi
	echo ''
	echo -e "Server started \033[1;36mhttp://localhost:$port\033[1;39m"
	echo ''
	echo "press ctrl + c for exit"
	while [ 1 ]
	do
		if [ -d $HOME/payload ]
		then
			cd $HOME/payload && php -S localhost:$port > /dev/null 2>&1 &
			sleep 1
		fi
	done
fi
